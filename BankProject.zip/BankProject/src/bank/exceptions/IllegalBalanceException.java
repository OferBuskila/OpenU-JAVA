package bank.exceptions;

public class IllegalBalanceException extends Exception {

	public IllegalBalanceException(String message) {
		super(message);
	}
}
