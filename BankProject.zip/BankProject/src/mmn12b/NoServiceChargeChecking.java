package mmn12b;

public class NoServiceChargeChecking extends CheckingAccount{

	protected final double minBalance = 100;
	
	public NoServiceChargeChecking(int _accNum, String _ownName, String _id,
			double _balance) {
		super(_accNum, _ownName, _id, _balance);
	}

	public NoServiceChargeChecking() {
	}

	@Override
	void accAdmin() {
		
	}
	
	@Override
	protected boolean writeCheck(double amount) {
		if (!(balance < minBalance)){
			balance -= amount;
			return true;
		}
		else
			return false;
	}
}
