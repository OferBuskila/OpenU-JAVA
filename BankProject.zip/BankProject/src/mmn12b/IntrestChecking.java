package mmn12b;

public class IntrestChecking extends NoServiceChargeChecking{

	private final int minBalance = 200;
	private double intrest = 10; 
	public IntrestChecking(int _accNum, String _ownName, String _id,
			double _balance) {
		super(_accNum, _ownName, _id, _balance);
	}
	
	public IntrestChecking() {
	}

	@Override
	void accAdmin() {
		//set the new balance after the intrest.
		balance = (balance + calIntrest());
	}
	
	@Override
	protected boolean withdraw(double amount) {
		if (!(balance < minBalance)){
			balance -= amount;
			return true;
		}
		else{
			return false;
		}
	}
	
	/**
	 * Calculate the intrest from the current balance
	 * @return
	 * return the calculated intrest to add to the balance.
	 */
	public double calIntrest(){
		double interestValue = (balance * intrest)/100;
		return balance + interestValue;
	}

	/**
	 * @return the intrest
	 */
	public double getIntrest() {
		return intrest;
	}

	/**
	 * @param intrest the intrest to set
	 */
	public void setIntrest(double intrest) {
		this.intrest = intrest;
	}
	

}
