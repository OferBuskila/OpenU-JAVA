package mmn12b;

public abstract class BankAccount {
	protected int accNum;
	protected String ownName;
	protected String id;
	protected double balance;
	
	public BankAccount(){
		
	}
	public BankAccount(int _accNum, String _ownName, String _id, double _balance) {
		accNum = _accNum;
		ownName = _ownName;
		id = _id;
		balance = _balance;
	}
	
	abstract void accAdmin();
	
	/**
	 * Deposit money to this account
	 * @param sum
	 * 	-The amount to deposit
	 */
	protected void deposit(double sum){
		balance += sum;
	}
	
	/**
	 * Withdraw money from the account only if this account has money in it.
	 * 
	 * @param amount
	 * 	-The money to withdraw
	 * @return 
	 * 	true if the action was performed successfully
	 * 	false otherwise.
	 * 
	 */
	protected boolean withdraw(double amount){
		boolean result = true;
		if(balance - amount < 0){
			result = false;
		}
		else{
			balance -= amount;
		}
		return result;
	}
	
	public String toString(){
		String output = "";
		output = output + "Account number: " + accNum + "\n" +
				"Owner's name: " + ownName + "\n" +
				"Owner's ID: " + id +"\n" +
				"Balance: " + balance + "\n" +
				"==========================================";
		return output;
	}

}
