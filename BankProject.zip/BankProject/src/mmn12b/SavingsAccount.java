package mmn12b;

public class SavingsAccount extends BankAccount{
	private double interst;
	
	public SavingsAccount(int _accNum, String _ownName, String _id,
			double _balance) {
		super(_accNum, _ownName, _id, _balance);
	}

	public SavingsAccount() {
	}

	@Override
	void accAdmin() {
		balance = (balance + calInterest());
	}


	/**
	 * Calculate the intrest from the current balance
	 * @return
	 * return the calculated intrest to add to the balance.
	 */
	public double calInterest(){
		double interestValue = (balance * interst)/100;
		return balance + interestValue;
	}
	
	/**
	 * @return the interst
	 */
	public double getInterst() {
		return interst;
	}

	/**
	 * @param interst the interst to set
	 */
	public void setInterst(double interst) {
		this.interst = interst;
	}
	
}
