package mmn12b;

public class ServiceChargeChecking extends CheckingAccount{
	
	/**
	 * the fee to charge every month.
	 */
	private final double fee = 10;
	public ServiceChargeChecking(int _accNum, String _ownName, String _id,
			double _balance) {
		super(_accNum, _ownName, _id, _balance);
		
	}
	public ServiceChargeChecking() {
		
	}
	
	@Override
	/**
	 * Charge the fee from the account's balance.
	 */
	void accAdmin() {
		balance = balance - fee;
	}
	
	
	
	

}
