package mmn12b;

public abstract class CheckingAccount extends BankAccount{

	public CheckingAccount(){
		
	}
	
	public CheckingAccount(int _accNum, String _ownName, String _id,
			double _balance) {
		super(_accNum, _ownName, _id, _balance);
	}
	
	/**
	 * withdraw money from the account using checks.
	 * No limit on the account's withdraw possibility.
	 * Functions that wish to override this function should return false if the operation
	 * didn't end successfully for some reason.
	 * @param amount 
	 * 	-The amount of money to withdraw.
	 * @return 
	 * 	true.
	 */
	protected boolean writeCheck(double amount){
		balance -= amount;
		return true;
	}
}
